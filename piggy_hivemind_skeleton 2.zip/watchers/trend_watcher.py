# placeholder trend watcher
