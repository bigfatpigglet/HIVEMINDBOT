# Piggy Hivemind
Quick-start skeleton for the numerology‑synced AI‑guided trading hive.

1. `python3 -m venv venv && source venv/bin/activate`
2. `pip install -r requirements.txt`
3. `cp .env.example .env` and fill secrets
4. `python temple_interface.py`  (or `./supervisor/run_all.sh`)

See temple_interface.py for the integrated console + bots.
